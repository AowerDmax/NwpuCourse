│toc
│   README.txt
│   
├───Class_1
│       exercise.bat -- 运行脚本,执行三个exe文件,采用12的测试用例
│       exercise_1.c -- 斐波那契数列 求兔子的数量
│       exercise_1.exe
│       exercise_2.c -- 挑战大数存储问题 40的阶乘
│       exercise_2.exe
│       exercise_3.c -- 杨辉三角
│       exercise_3.exe
│       
├───Class_10
│       exercise_1.bat
│       exercise_1.c -- floyed 求多源最短路径
│       exercise_1.exe
│       
├───Class_11
│       exercise_1_1.bat
│       exercise_1_1.c -- 数组模拟堆 循环堆记录资源消耗量 并输出每天售出的飞机
│       exercise_1_1.exe
│       exercise_1_2.bat
│       exercise_1_2.c -- 数组模拟堆 使用哈希表存储入堆时间计算资源消耗量 并输出每天售出的飞机和该飞机在哈希表中存储的位置
│       exercise_1_2.exe
│       exercise_2.bat
│       exercise_2.c -- 贪心思想求最小次数 并输出每次的变化
│       exercise_2.exe
│       out_t1.txt -- 输出结果
│       out_t1_1.txt -- 输出结果
│       out_t2.txt -- 输出结果
│       t1.txt -- 测试用例
│       t2.txt -- 测试用例
│       
├───Class_2
│       exercise.bat -- 运行脚本, 采用3测试用例模拟三次发牌
│       exercise_1.c -- 斗地主模拟发牌
│       exercise_1.exe
│       
├───Class_3
│       data.txt - 测试用例
│       exercise.bat
│       exercise_1.c -- Ipv4 Ipv6 地址判别 如果错误并输出错误原因
│       exercise_1.exe
│       IPv4Eval.c -- 判断Ipv4
│       Ipv4Eval.h
│       Ipv6Eval.c -- 判断Ipv6
│       Ipv6Eval.h
│       
├───Class_4
│       exercise.bat
│       exercise_1.c -- 单向链表的建立、插入和删除
│       exercise_1.exe
│       
├───Class_5
│       exercise_1.bat
│       exercise_1.c -- 双向链表的建立、插入和删除
│       exercise_1.exe
│       exercise_2.bat
│       exercise_2.c -- 单向循环链表的建立、插入和删除
│       exercise_2.exe
│       
├───Class_6
│       exercise.bat
│       exercise_1.c -- 搜索二叉树的建立、插入、删除以及遍历 (前序遍历、中序遍历、后序遍历、dfs、bfs) 五种遍历方式
│       exercise_1.exe
│       
├───Class_7
│       exercise.bat
│       exercise_1.c -- 逆波兰表达式 并输出源中序表达式
│       exercise_1.exe
│       
├───Class_8
│       exercise.bat
│       exercise_1.c -- 跳舞者队列匹配
│       exercise_1.exe
│       
└───Class_9
        exercise_1.bat
        exercise_1.c -- 图的建立、深度优先搜索与广度优先搜索 链表头插法实现
        exercise_1.exe
        exercise_2.bat
        exercise_2.c -- 图的建立、深度优先搜索与广度优先搜索 链表尾插法实现
        exercise_2.exe
        exercise_3.bat
        exercise_3.c -- 图的建立、深度优先搜索与广度优先搜索 数组邻接数组实现
        exercise_3.exe
        exercise_4.bat
        exercise_4.c -- 图的建立、深度优先搜索与广度优先搜索 数组模拟邻接表实现
        exercise_4.exe
        
