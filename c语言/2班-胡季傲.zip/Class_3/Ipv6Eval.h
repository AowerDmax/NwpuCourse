#ifndef Ipv6Eval
#define Ipv6Eval

int ipv6Eval(char q[]);

#endif