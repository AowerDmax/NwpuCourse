#ifndef Ipv4Eval
#define Ipv4Eval

int ipv4Eval(char q[]);

#endif